$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/test/java/features/book.feature");
formatter.feature({
  "line": 1,
  "name": "Curso de automation",
  "description": "",
  "id": "curso-de-automation",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 3,
  "name": "Search a book",
  "description": "",
  "id": "curso-de-automation;search-a-book",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 5,
  "name": "I enter search \u003csearch\u003e",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "I click Search button",
  "keyword": "And "
});
formatter.step({
  "line": 7,
  "name": "I sort the list results by \u003corder\u003e",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "I click on the first element",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "The desctiption screen should be displayed",
  "keyword": "Then "
});
formatter.examples({
  "line": 12,
  "name": "",
  "description": "",
  "id": "curso-de-automation;search-a-book;",
  "rows": [
    {
      "cells": [
        "search",
        "order"
      ],
      "line": 13,
      "id": "curso-de-automation;search-a-book;;1"
    },
    {
      "cells": [
        "Sailor moon tomo 7",
        "price_low_high"
      ],
      "line": 14,
      "id": "curso-de-automation;search-a-book;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 7523202966,
  "status": "passed"
});
formatter.scenario({
  "line": 14,
  "name": "Search a book",
  "description": "",
  "id": "curso-de-automation;search-a-book;;2",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 5,
  "name": "I enter search Sailor moon tomo 7",
  "matchedColumns": [
    0
  ],
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "I click Search button",
  "keyword": "And "
});
formatter.step({
  "line": 7,
  "name": "I sort the list results by price_low_high",
  "matchedColumns": [
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "I click on the first element",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "The desctiption screen should be displayed",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "Sailor moon tomo 7",
      "offset": 15
    }
  ],
  "location": "SearchBook.i_enter_search(String)"
});
formatter.result({
  "duration": 2351253758,
  "status": "passed"
});
formatter.match({
  "location": "SearchBook.i_click_Search_button()"
});
formatter.result({
  "duration": 1249723347,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "price_low_high",
      "offset": 27
    }
  ],
  "location": "SearchBook.i_sort_the_list_result_by(String)"
});
formatter.result({
  "duration": 3295296052,
  "status": "passed"
});
formatter.match({
  "location": "SearchBook.i_click_on_the_first_element()"
});
formatter.result({
  "duration": 1743861839,
  "status": "passed"
});
formatter.match({
  "location": "SearchBook.the_desctiption_screen_should_be_displayed()"
});
formatter.result({
  "duration": 897677417,
  "status": "passed"
});
formatter.write("--------------------------------------------------------------");
formatter.write("ID: curso-de-automation;search-a-book;;2");
formatter.write("Name : Search a book");
formatter.write("Status : passed");
formatter.write("Price: ARS$284,90");
formatter.embedding("image/png", "embedded0.png");
formatter.write("--------------------------------------------------------------");
